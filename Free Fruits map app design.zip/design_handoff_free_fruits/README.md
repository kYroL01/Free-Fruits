# Handoff: Free Fruits — forager map app (iOS + Android)

## Overview
Free Fruits is a mobile app for mapping free, public, edible plants in a city (starting with Milan / Navigli). Foragers photograph a tree on site, the photo's GPS proves it exists, the community confirms it, and the finder earns **strawberry points** that convert into status tiers, funded saplings, and unlocked map layers.

Product line: *"Nothing ripe should rot."* Activist tone, forager-first. **The map is the product** — every other screen is one tap from it.

Core loop:
1. Open map → see nearby edible pins ranked by rarity and distance.
2. Tap `+` → photograph the tree on site (GPS stamped) → identify species → place pin → submit.
3. Points land **pending** until 2 foragers confirm on site.
4. Passing another forager's tree → check in (+5 first time, +3 repeats) and report condition.
5. Spend points: sapling (500), rare-fruit layer (300), tier progress (Orchardist at 2,000).

## About the design files
The files in this bundle are **design references created in HTML** — a working prototype of the intended look, copy, and behaviour. They are **not production code to copy**. The task is to **recreate these designs natively** in the target environment: React Native / Expo, Flutter, or SwiftUI + Jetpack Compose. Match the layout, spacing, type, and colours exactly; implement the behaviour described below with the platform's own primitives (camera, EXIF/GPS, map SDK, haptics, share sheet).

`Free Fruits.dc.html` is the whole app in one file. It opens in a browser. `ios-frame.jsx` is only the device bezel used for presentation — ignore it when implementing.

Platform notes that the HTML cannot express:
- The map is a **stylised fake** in the prototype (CSS shapes for roads, parks, canal). In the real app use MapLibre / Mapbox / Google Maps with a custom style matching the token palette (`--ff-land`, `--ff-road`, `--ff-park`, `--ff-water` below), plus a dark style variant.
- The camera screen must be a real in-app capture that writes GPS into the image; gallery uploads without EXIF GPS hit the "no location" refusal modal.
- The bottom tab bar assumes a 34pt home-indicator inset on iOS; on Android use the system navigation inset and a 3-dot-free layout.

## Fidelity
**High-fidelity.** Final colours, typography, spacing, copy, and interaction states. Recreate pixel-accurately, but substitute platform-native controls where the HTML fakes them (switches, sliders, sheets, share sheet, text fields). Every hex, font size, and radius below is the intended value at a 402 × 874 pt logical viewport (iPhone 16 Pro class); scale proportionally, do not rescale type.

---

## Design tokens

### Colour — light (default)
| Token | Hex | Use |
|---|---|---|
| `bg` | `#F5F7F2` | app background |
| `surface` | `#FFFFFF` | cards, sheets, tab bar |
| `surface2` | `#EDF1E9` | inset wells, disabled buttons, photo placeholders |
| `text` | `#10160F` | primary text, dark action buttons |
| `dim` | `#6C7A6E` | secondary text, mono labels |
| `line` | `rgba(16,22,15,.10)` | 1px borders, dividers |
| `green` | `#12734A` | verified, Common rarity, positive |
| `green-soft` | `#E2F1E6` | green backgrounds |
| `fuchsia` | `#D4148B` | brand / primary action, Rare rarity, points |
| `fuchsia-soft` | `#FCE3F1` | fuchsia backgrounds |
| `gold` | `#A87400` | Legendary rarity, warnings |
| `gold-soft` | `#F7EBCF` | gold backgrounds |
| `land` | `#E9ECE1` · `road` `#FFFFFF` · `park` `#D6E8CE` | map base |
| `water` | `#CDDFEA` | canal / water |
| `ph` | `rgba(16,22,15,.06)` | 45° hatched photo placeholder stripes |

### Colour — dark
| Token | Hex |
|---|---|
| `bg` | `#0D1210` |
| `surface` | `#161D18` |
| `surface2` | `#1E2721` |
| `text` | `#EDF3EC` |
| `dim` | `#8FA093` |
| `line` | `rgba(255,255,255,.13)` |
| `green` | `#43C384` · soft `rgba(67,195,132,.15)` |
| `fuchsia` | `#FF57BC` · soft `rgba(255,87,188,.16)` |
| `gold` | `#EFC154` · soft `rgba(239,193,84,.16)` |
| `land` `#121814` · `road` `#212A23` · `park` `#18291C` · `water` `#152431` · `ph` `rgba(255,255,255,.07)` |

Dark mode is user-toggled from the map header **and** from Profile → Settings. It is not tied to the system setting by default (offer a "Match system" option if the platform expects one).

### Typography
Three families, loaded as app fonts:
- **Archivo** (500/600/700/800) — all headings, buttons, names, numbers-in-headings.
- **DM Sans** (400/500/700) — body copy, list rows, descriptions.
- **IBM Plex Mono** (500/600) — kickers, labels, counts, points, statuses. Always uppercase with letter-spacing `.04–.10em`.

| Role | Spec |
|---|---|
| Screen title | Archivo 800, 26px/1.1, `-0.03em` |
| Detail title | Archivo 800, 27px/1.1, `-0.03em` |
| Sheet title | Archivo 800, 21px/1.15, `-0.02em` |
| Success headline | Archivo 800, 40px/1.02, `-0.035em` |
| Card title | Archivo 700, 15–16px, `-0.01/-0.02em` |
| Row title | Archivo 700, 13–13.5px, `-0.01em` |
| Primary button | Archivo 700, 14px |
| Body | DM Sans 400, 11.5–13px, line-height 1.5–1.65 |
| Row label | DM Sans 500, 12.5–13px |
| Section kicker | IBM Plex Mono 600, 9.5px, `.09em`, uppercase, `dim` |
| Micro label | IBM Plex Mono 600, 8.5px, `.05em`, uppercase |
| Points big | IBM Plex Mono 700, 44–54px |
| Points inline | IBM Plex Mono 700, 11–22px, fuchsia |

### Spacing / geometry
- Screen padding: `18px` horizontal, `58px` top (below status bar), `28px` bottom above the tab bar.
- Vertical rhythm between sections: `18–24px`; kicker sits `22px` below the previous block, `10px` above its content.
- Radii: pill/track `14px`, cards `13–18px`, sheets/modals `22–24px`, map panel `20–22px`, small chips `8–12px`, icon tiles `9–12px`.
- Shadows: cards `0 10px 26px rgba(0,0,0,.13)`; floating header `0 6px 20px rgba(0,0,0,.10)`; sheets `0 18px 50px rgba(0,0,0,.32)`; map pins `0 4px 12px rgba(0,0,0,.28)`; FAB `0 8px 20px rgba(212,20,139,.4)`.
- Borders: 1px `line` for containers, **1.5px** for selectable/selected states.
- Toggle switch: 42 × 24, knob 18px, travel left 3 → 21, 180ms.

### Rarity system
| Rarity | Colour | Points | Examples |
|---|---|---|---|
| Common | `green` | 10–15 | orange, lemon, apple, basil, mint |
| Rare | `fuchsia` | 25–35 | fig, loquat, plum, sage, thyme |
| Legendary | `gold` | 40–50 | peach, cherry, mulberry, wild fennel |
| Unrated | — | 15 | user-typed species; a community botanist sets rarity after verification |

---

## Screens

### 1. Map (home, default tab)
**Purpose:** see what is edible around you right now.

**Layout, top → bottom, over a full-bleed map:**
- **Floating location bar** (`surface`, radius 14, padding 11/13, shadow): 8px green dot · stacked `NEAREST CITY · AUTO` (mono 9px, dim) over `Milan — Navigli` (Archivo 700 14px) · **FILTER** pill on the right (mono 10px, fuchsia text, 1px fuchsia border, radius 8) → opens Filters.
- **Theme button**, 44 × 44 beside it, same surface treatment, label `DARK` / `LIGHT`.
- **Proximity prompt card** (fuchsia, radius 16, shadow `0 10px 28px rgba(0,0,0,.22)`), shown when the user is within ~12 m of an unverified pin: kicker `YOU'RE 12 M AWAY`; headline "Someone logged a pomegranate here. Is it real?" (Archivo 700 15px, white); two buttons — **Yes, it's there** (white fill, fuchsia text) opens that tree's detail with the condition report sheet already open; **Not there** (transparent, 1.5px white border) dismisses for the session.
- **Pins:** 34 × 34, rotated-square teardrop (`border-radius: 50% 50% 50% 4px`, rotate 45°), 2.5px `surface` border, fill = rarity colour, species initial in white Archivo 700 12px (counter-rotated). Anchor point is the pin tip.
- **User location:** 16px fuchsia dot, 3px white ring, with a pulsing halo (scale 1 → 2.4, opacity .55 → 0, 2.4s ease-out, infinite).
- **Results bar** above the carousel: "{n} trees within {radius}" (Archivo 700 13px) + **SEE ALL** → Filters.
- **Nearby carousel:** horizontal snap list, 212px cards, 12px gap, 16px side padding. Card = 84px hatched photo placeholder with rarity badge, species name (Archivo 700 16px) + `+pts` (mono 13px fuchsia), `{distance} · {street}` (DM Sans 11.5px dim), then a divider row with a status dot (fuchsia = pending, green = verified), status text, and the latest condition short (`FRUITING` / `RIPENING` / `DRY` …) coloured green (good) or gold (bad).
- **Empty state** when filters exclude everything: card reading "Nothing matches these filters" + **LOOSEN THEM**.

**Tab bar** (88px tall incl. 30px bottom inset, `surface`, 1px top border): MAP · POINTS · **+ FAB** · ALERTS · YOU. Icons are 18px outline geometry, labels mono 8.5px `.05em`; active = fuchsia, inactive = dim. FAB is 52 × 52, radius 18, fuchsia, lifted −16px, white `+` at 26px.

### 2. Tree detail
Scrolls under a 300px hatched photo header. Back chip (38 × 38, radius 12, surface) top-left at y=58; rarity badge top-right (mono 10px white on the rarity colour, radius 8).

Body, 18px padding, 18px gaps:
- **Title row:** species (Archivo 800 27px) + `{street} · {distance} away`; right-aligned `+{pts}` (mono 22px fuchsia) over `STRAWBERRY PTS`.
- **Verification block** (radius 16, `green-soft` when verified / `fuchsia-soft` while pending): heading `VERIFIED BY COMMUNITY` or `NEEDS N MORE CHECKS`, right-side count (`4 on-site OKs` or `1 / 2 needed`); a 4-segment progress bar (5px, filled segments opacity 1, rest .25); explanatory body ("Photo carried GPS matching the pin within 3 m…"); then a finder row — 26px rounded initial tile, `DISCOVERED BY`, handle · date, and `PERMANENT CREDIT` on the right. **Discovery credit never transfers.**
- **Condition card:** 30px glyph tile (`OK` green / `!` gold), `CONDITION · LATEST REPORT`, the report label, and when/who on the right.
- **Season strip:** 12 month bars (26px tall, radius 5) — current month solid fuchsia, in-season months `fuchsia-soft`, out `surface2` — with a note below in green when in season.
- **Access list:** three rows, coloured dot + fact ("Public pavement — no fence…", "Busy road — mind the traffic side").
- **Actions:** primary check-in button whose label and enablement follow the check-in rules (below); helper line underneath; then **Walk me there** (dark fill, becomes "Walking · {n} min · {dist}") + a 52px **FLAG** button (becomes `SENT`).

### 3. Add a tree — 3 steps
Header: `×`, step title, `STEP n OF 3`, and a 3-segment progress bar.

**Step 1 — Prove it on site.** Full-bleed camera in a 22px-radius black frame. Overlay chips: `GPS LOCKED · 3 M` (green dot) and live coordinates. Centre 180 × 180 dashed guide: "Frame the whole tree, standing at its trunk". Bottom: "Location is stamped into the photo", then `UPLOAD` · 66px fuchsia shutter · `FLASH`. Upload path with no EXIF GPS → **no-location modal** (below).

**Step 2 — What is it?** 150px photo thumb with its coordinates. **Auto-match card** ("Fig — 92% match · Rare · worth 30 points", fuchsia-soft, CTA `USE` → `SELECTED`). Kind segmented pair: **Fruit tree** / **Herb or green**. 3-column species grid (rarity dot, name, `+pts`); selecting outlines the tile 1.5px fuchsia — **it does not advance**. "None of these?" free-text field + **Use** button (unlisted = 15 pts, Unrated). Sticky footer button: disabled "Pick a species first" → "Confirm {species} · +{pts}".

**Step 3 — Where exactly?** Draggable pin on a mini map (pointer capture; pin scales 1.12 while dragging, eases 180ms on release). Caption switches from `PIN FROM PHOTO METADATA` / "drag the pin if the trunk sits elsewhere" to `PIN ADJUSTED BY HAND` / "Moved {n} m from the photo location". Two summary tiles (species · rarity, and points earned), then **Share this tree** and "Points land as pending until 2 foragers confirm on site".

### 4. Points
Title "Strawberry points". Dark card: `1,240` (mono 44px) + `EARNED · 34 TREES`; tier progress bar FORAGER → ORCHARDIST at 62%, "760 points to Orchardist". `SPEND THEM` list of three reward cards (title, body, cost, progress bar, CTA): Fund a real sapling 500 · Rare-fruit map layer 300 · Orchardist tier 2,000 (`Locked`). `TIERS` row of four: Sprout 0 · Picker 250 · Forager 1K (current, fuchsia border) · Orchardist 2K.

### 5. Alerts
Title "Alerts" + `MARK ALL READ`. Rows: coloured dot, title (Archivo 700 13.5px), body, right-aligned relative time (`NOW`, `2H`, `1D`). Tinted background for actionable items (fuchsia-soft for a nearby unverified tree, gold-soft for a claim under review, green-soft for a reopened check-in). Tapping navigates to the relevant tree or screen; informational rows are inert.

### 6. Filters
Search field (fruit, street, or forager). `WHAT TO SHOW`: Fruit trees / Herbs & greens chips with counts. `RARITY`: Common / Rare / Legendary chips, each filled with its own rarity colour when on. `DISTANCE · {label}`: slider stepping 300 M → 600 M → 2 KM → 5 KM → CITY-WIDE. `ONLY SHOW` switch rows: Verified trees only · In season right now · Reachable without a fence · Trees I have not visited. Footer CTA is live: "Show {n} results", "Show all {n} results" when nothing is constrained, or the disabled "Nothing matches — loosen a filter".

**Filter semantics (important):** within a chip group, *all chips off* means **no constraint**, not "no results" — the map never goes blank by accident.

### 7. You (profile)
Avatar (60px, radius 20) with a fuchsia `+` badge → avatar sheet. Editable display name (tap → inline field with **Save**), handle line "Forager · Milan · since 2025". Tier card: Forager, `1,240 / 2,000`, gradient bar green→fuchsia at 62%, SPROUT ↔ ORCHARDIST. `MY TREES · 34` list rows (initial tile, name, street, VERIFIED / PENDING 1/2, points). `SETTINGS` grouped card: Dark mode switch · Invite a forager (shows invite link, +10 pts per join) · Units METRIC/IMPERIAL · Privacy & my location history ›.

### 8. Privacy & location
Back chip + title. Intro: "A foraging map only works if the trees are real, so photos carry GPS. Everything about *you* is a choice."
- `WHAT WE STORE`: GPS inside your tree photos — **KEPT**; Pins you opened — **30 DAYS**; Your live position — **NEVER STORED**.
- `MY TREES ON THE PUBLIC MAP` radio group: Exact pin · Blurred to 100 m · Only me (no points until published).
- `TRACKING` switches: Keep a trail of my walks (on) · Share anonymised harvest counts (off).
- `LOCATION HISTORY · 148 POINTS · 62 DAYS`: body copy, **Wipe my location history** (two-tap confirm: "Tap again to confirm" → "History wiped", turns green) and **EXPORT** → `SENT`. Footnote: wiping keeps the trees, removes only the trail.

---

## Modals & overlays
All are centred cards, 18px side margins, max-height 80% with internal scroll, 24px radius, 20px padding, 38 × 4 grab handle, scrim `rgba(8,14,8,.5–.62)`. Tapping the scrim dismisses (except the duplicate flow and success).

- **No location in photo** — icon tile `!`, "This photo has no location in it", explanation, **Open camera** (dark) / **Later**.
- **Condition report** (2 steps) — step 1: Good (green) vs Bad (gold) tiles, plus "Either answer is worth the same points — a dying tree is as useful to know about as a full one." Step 2: radio list — Good: Fruit ready to pick / Fruit still ripening / Season over. Bad: Disease or pest / Dry / Burnt / Cut back or removed / Fenced off. Footer BACK + **Submit report · +{5 or 3}** (disabled until a reason is picked). Header badge `GPS 4 M`.
- **Duplicate detected** (2 steps) — step 1: "Something already exists 8 m away", the existing pin's card, then **Same tree · +5** (green) or **It's a new one**. Step 2: "Tell us how it differs" — required reason radio (different species / second trunk 8 m away / existing pin is on the wrong tree), a gold note that the original finder reviews it, and a strike meter row: "A rejected claim costs nothing on its own. **Three rejected claims: −5 points.**" with 3 dots. **Submit for review** is disabled until a reason is chosen.
- **Success** — full-bleed fuchsia. Kicker (`PENDING COMMUNITY CHECK` or `POINTS HELD · DUPLICATE REVIEW`), headline (Archivo 800 40px), `+{n}` (mono 54px) `STRAWBERRY POINTS`, rule, body, then **See my points** / **Back to map**.
- **Avatar** — "Use a photo" (camera or library) and an "INITIALS" tile, then `OR PICK FROM NATURE`: a 4-column grid of 8 illustrated plant avatars (Fig, Lemon, Olive, Peach, Mint, Cactus, Rosemary, Dandelion), each a gradient body with a white highlight sweep and leaf. Selected = 1.5px fuchsia border. **Done**. (The 8 avatar SVG path sets are in the prototype's `AVATARS` array — lift them verbatim, or re-draw as native vector assets.)
- **Invite link** — `freefruits.app` / `{code}` chips + **NEW CODE**, the full link with **Copy** (→ green "Copied"), hint "Old links keep working for 30 days after you make a new one", then four share targets (Messages, WhatsApp, Mail, More) — on device, replace with the native share sheet. **Done**.

---

## Points & anti-farming rules
These are the product's spine — implement them server-side, never trust the client.

| Action | Award |
|---|---|
| Log a new tree | species points (10–50), **pending** until 2 on-site confirmations |
| Unlisted species | 15, rarity assigned later by a community botanist |
| Confirm an existing tree is the same one | +5 immediately |
| First check-in at someone else's tree | +5 |
| Repeat check-in at the same tree | +3 |
| Friend joins from your invite | +10 |

Constraints:
- **Proof:** photo must carry GPS within ~3 m of the pin. No EXIF GPS → refused.
- **Proximity:** check-ins unlock only within **25 m** of the pin.
- **Cooldown:** one scoring check-in per tree per **30 days**; the button shows "Reported · opens in {n} days".
- **Season gate:** check-ins score only while the species is in season; otherwise "Out of season · opens in {Month}".
- **Own trees:** the finder cannot check in on their own tree ("Your discovery · credit is yours").
- **Duplicates:** a pin within 8 m of an existing one forces the duplicate flow. Claiming a separate tree requires a stated reason, **holds all points**, and routes to the original finder plus two foragers. Rejection costs nothing; **three rejected claims = −5 points**.
- **Discovery credit is permanent** and shown on every tree detail.
- Reopened check-ins generate an alert when a tree is in season and the user's last report is ≥ 30 days old.

## State model
Per-session UI state in the prototype (maps to view models / stores):

```
screen        map | detail | add | rewards | notifications | profile | privacy | search(filters)
overlay       null | report | dup | success | avatar | share | nogeo
dark          bool                     selIdx     index of the open tree
addStep       1 | 2 | 3                pick       { name, rarity, pts, kind }  + picked bool
pinX/pinY     % position of dragged pin, pinMoved, pinDist (metres)
rarity        { Common, Rare, Legendary: bool }   kinds { fruit, herb: bool }
radius        0–4 index into [300, 600, 2000, 5000, ∞] metres
tg            [verifiedOnly, inSeason, noFence, notVisited]
reports       { treeIdx: { kind: good|bad, sub } }   flagged {}  viewed {}
dupStep 1|2 · dupReason · claimHeld · claimed · strikes
precision     exact | blur | private     pv [walkTrail, shareHarvest]
name · nameDraft · editingName · avatar { type: initials|photo|preset, glyph }
codeSeed (invite code) · copied · shareTarget · wipeArmed · wiped · exported
earned        session points, added to a 1,240 baseline
```

**Server data needed:** trees (id, species, rarity, points, lat/lng, street, finder, confirmations, pending flag, fence flag, season window, latest condition report, photo), user (points, tier, trees, strikes, invite code, privacy settings), alerts feed, and the species catalogue (name, rarity, points, season) shipped below.

### Species catalogue (seed data)
Fruit: Fig Rare 30 · Peach Legendary 50 · Orange Common 10 · Lemon Common 15 · Mulberry Legendary 45 · Loquat Rare 35 · Plum Rare 30 · Cherry Legendary 50 · Apple Common 15.
Herbs & greens: Basil Common 10 · Wild mint Common 10 · Rosemary Common 15 · Parsley Common 10 · Sage Rare 25 · Thyme Rare 25 · Oregano Common 15 · Bay laurel Rare 25 · Wild fennel Legendary 40.
Season windows (month indices, 0 = January, inclusive, wrapping): Fig 5–8 · Peach 6–7 · Mulberry 5–6 · Loquat 3–4 · Orange 10–2 · Wild mint 3–6 · Rosemary 0–11 · Pomegranate 7–10.

## Interactions & motion
- Tab changes and screen pushes are instant in the prototype; on device use the platform's standard push/fade. Overlays should animate in (scrim fade 150ms, card 200ms ease-out).
- Toggle knob and track: 180ms.
- Pin drag: pointer capture, scale 1.12 while held, `left/top` ease 180ms on release; snap nothing — the user's placement wins.
- User-location halo: 2.4s infinite pulse.
- Copy button: label swaps to "Copied" and turns green; do not revert during the session.
- Destructive actions use two-tap arming rather than a confirm dialog (see Wipe history).
- Haptics (add on device): light on chip/toggle, medium on shutter and pin drop, success on points awarded.

## Accessibility
- Minimum tap target 44 × 44 — the mono micro-labels are decoration; the whole row/card is the target.
- Mono uppercase labels must carry accessible names in sentence case for screen readers.
- Rarity is colour-coded **and** always labelled in text — never colour alone.
- Support Dynamic Type / font scaling at least to 130% on body and row text; headings may cap.
- Check contrast in dark mode for `dim` on `surface` (currently ~4.6:1).

## Assets
No bitmap assets. Everything is drawn:
- Photo areas are 45° hatched placeholders in the prototype — replace with real user photos and a matching skeleton state.
- 8 plant avatars: inline SVG paths in the `AVATARS` constant of `Free Fruits.dc.html`.
- Tab icons are simple geometric outlines (square, circle, rounded pill) — replace with a proper icon set matching 2px stroke weight.
- Fonts: Archivo, DM Sans, IBM Plex Mono (Google Fonts, SIL Open Font License — bundle them, don't fetch at runtime on mobile).

## Screenshots
`screenshots/` — 804 × 1748 px (2× of the 402 × 874 pt design viewport), captured from the prototype.

| File | State |
|---|---|
| `01-map.png` | Map, light, with the 12 m proximity prompt |
| `02-tree-detail.png` | Tree detail (Fig, verified, own discovery) |
| `03-add-step1-camera.png` | Add step 1 — on-site camera with GPS lock |
| `04-add-step2-species.png` | Add step 2 — auto-match, kind toggle, species grid |
| `05-add-step3-pin.png` | Add step 3 — draggable pin + summary |
| `06-duplicate-detected.png` | Duplicate modal, step 1 |
| `07-separate-tree-claim.png` | Duplicate modal, step 2 — reason picked, strike meter |
| `08-success-points-held.png` | Success — points held pending duplicate review |
| `09-points.png` | Points: balance, tier bar, rewards, tiers |
| `10-alerts.png` | Alerts feed |
| `11-profile.png` | You — profile, my trees, settings |
| `12-avatar-picker.png` | Avatar sheet with the 8 plant avatars |
| `13-invite-link.png` | Invite link sheet |
| `14-privacy.png` | Privacy & location history |
| `15-filters.png` | Filters — chips, distance, switches, live CTA |
| `16-condition-report.png` | Condition report, step 1 (Good / Bad) |
| `17-report-options.png` | Condition report, step 2 (reasons) |
| `18-map-dark.png` | Map, dark mode |
| `19-tree-detail-dark.png` | Tree detail, dark mode |

## Files
- `Free Fruits.dc.html` — the full prototype: all 8 screens, 7 overlays, and the complete state logic. Open in a browser; the logic class at the bottom of the file is the behavioural spec.
- `ios-frame.jsx` — presentation-only device bezel. Not part of the app.
- `support.js` — prototype runtime. Not part of the app.
